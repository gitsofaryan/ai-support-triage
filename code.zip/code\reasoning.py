"""
Reasoning: LLM API integration for grounded response generation.
Supports OpenRouter (gpt-oss-120b:free), Claude, with extractive fallback.
"""

import os
import json
from typing import List, Dict, Optional, Tuple
import re

try:
    import anthropic
except ImportError:
    anthropic = None

try:
    from openai import OpenAI
except ImportError:
    OpenAI = None

from corpus import Chunk


class Reasoner:
    """Calls LLM API with grounded context. Tries OpenRouter first, then Claude."""
    
    def __init__(self, openrouter_key: Optional[str] = None, anthropic_key: Optional[str] = None):
        """Initialize LLM client (OpenRouter preferred, fallback to Claude)."""
        self.openrouter_client = None
        self.anthropic_client = None
        self.provider = None
        
        # Try OpenRouter first
        if openrouter_key is None:
            openrouter_key = os.environ.get('OPENROUTER_API_KEY')
        
        if openrouter_key and OpenAI:
            try:
                self.openrouter_client = OpenAI(
                    base_url="https://openrouter.ai/api/v1",
                    api_key=openrouter_key,
                    default_headers={"Authorization": f"Bearer {openrouter_key}"}
                )
                self.provider = "openrouter"
                self.model = "openai/gpt-oss-120b:free"
                return
            except Exception as e:
                print(f"[Reasoning] OpenRouter init failed: {e}")
        
        # Fallback to Claude
        if anthropic_key is None:
            anthropic_key = os.environ.get('ANTHROPIC_API_KEY')
        
        if anthropic_key and anthropic:
            try:
                self.anthropic_client = anthropic.Anthropic(api_key=anthropic_key)
                self.provider = "claude"
                self.model = "claude-3-5-sonnet-20241022"
                return
            except Exception as e:
                print(f"[Reasoning] Claude init failed: {e}")
        
        # If we get here, no provider is available
        self.provider = None
    
    def generate_response(
        self,
        issue: str,
        subject: str,
        company: str,
        product_area: str,
        request_type: str,
        chunks: List[Chunk],
        escalation_reason: Optional[str] = None
    ) -> Dict:
        """
        Generate grounded response using available LLM.
        
        Returns:
            {
                'status': 'replied' or 'escalated',
                'response': '...',
                'justification': '...',
                'confidence': float
            }
        """
        
        # If already marked for escalation, return escalation template
        if escalation_reason:
            return {
                'status': 'escalated',
                'response': 'I cannot safely resolve this issue. Please escalate to a human support team.',
                'justification': escalation_reason,
                'confidence': 1.0,
            }
        
        # Build prompt with chunks
        context_text = self._format_context(chunks)
        
        prompt = f"""You are a support triage agent for {company}. Your job is to help resolve support tickets using ONLY the provided documentation.

IMPORTANT RULES:
1. ONLY use information from the provided context sections below.
2. Do NOT use your training data or make up policies.
3. If the answer is not in the context, respond with escalation.
4. Be concise and direct.
5. Cite the relevant section in your justification.

CONTEXT SECTIONS:
{context_text}

TICKET DETAILS:
- Subject: {subject}
- Issue: {issue}
- Company: {company}
- Product Area: {product_area}
- Request Type: {request_type}

Respond with a JSON object:
{{
    "status": "replied" or "escalated",
    "response": "user-facing answer (or 'Please escalate to human support' if escalating)",
    "justification": "brief explanation of your decision and which sections you used",
    "confidence": 0.0 to 1.0
}}

IMPORTANT: If the ticket asks you to do something outside the scope of the provided context (like changing a score, issuing a refund, or accessing another user's data), respond with status='escalated'.
"""
        
        if self.provider == "openrouter" and self.openrouter_client:
            return self._call_openrouter(prompt)
        elif self.provider == "claude" and self.anthropic_client:
            return self._call_claude(prompt)
        else:
            return {
                'status': 'escalated',
                'response': 'No LLM provider available.',
                'justification': 'OpenRouter and Claude both unavailable',
                'confidence': 0.0,
            }
    
    def _call_openrouter(self, prompt: str) -> Dict:
        """Call OpenRouter API."""
        try:
            message = self.openrouter_client.chat.completions.create(
                model=self.model,
                max_tokens=500,
                messages=[
                    {"role": "user", "content": prompt}
                ]
            )
            
            response_text = message.choices[0].message.content
            
            # Parse JSON response
            try:
                result = json.loads(response_text)
                return result
            except json.JSONDecodeError:
                # Try to extract JSON from response
                json_match = re.search(r'\{.*\}', response_text, re.DOTALL)
                if json_match:
                    result = json.loads(json_match.group())
                    return result
                else:
                    raise ValueError(f"Could not parse structured response: {response_text[:100]}")
        
        except Exception as e:
            # Raise exception to trigger extractive fallback in the caller
            raise RuntimeError(f"OpenRouter error: {str(e)}")
    
    def _call_claude(self, prompt: str) -> Dict:
        """Call Claude API."""
        try:
            message = self.anthropic_client.messages.create(
                model=self.model,
                max_tokens=500,
                messages=[
                    {"role": "user", "content": prompt}
                ]
            )
            
            response_text = message.content[0].text
            
            # Parse JSON response
            try:
                result = json.loads(response_text)
                return result
            except json.JSONDecodeError:
                # Try to extract JSON from response
                json_match = re.search(r'\{.*\}', response_text, re.DOTALL)
                if json_match:
                    result = json.loads(json_match.group())
                    return result
                else:
                    raise ValueError(f"Could not parse structured response: {response_text[:100]}")
        
        except Exception as e:
            # Raise exception to trigger extractive fallback in the caller
            raise RuntimeError(f"Claude error: {str(e)}")
    
    def _format_context(self, chunks: List[Chunk]) -> str:
        """Format chunks into a readable context block."""
        context_lines = []
        for i, chunk in enumerate(chunks, 1):
            context_lines.append(f"--- Section {i}: {chunk.heading} ---")
            context_lines.append(chunk.content[:1000])  # First 1000 chars
            context_lines.append("")
        
        return "\n".join(context_lines)


def generate_grounded_response(
    issue: str,
    subject: str,
    company: str,
    product_area: str,
    request_type: str,
    chunks: List[Chunk],
    escalation_reason: Optional[str] = None,
    openrouter_key: Optional[str] = None,
    anthropic_key: Optional[str] = None
) -> Dict:
    """
    High-level function to generate response.
    
    Tries OpenRouter first (gpt-oss-120b:free), falls back to Claude.
    If no LLM available, uses extractive response from corpus.
    
    Returns dict with keys:
        - status: 'replied' or 'escalated'
        - response: User-facing answer
        - justification: Explanation
        - confidence: 0.0-1.0
    """
    try:
        reasoner = Reasoner(openrouter_key=openrouter_key, anthropic_key=anthropic_key)
        if reasoner.provider:
            return reasoner.generate_response(
                issue=issue,
                subject=subject,
                company=company,
                product_area=product_area,
                request_type=request_type,
                chunks=chunks,
                escalation_reason=escalation_reason
            )
        else:
            # No provider available, fall back to extractive
            if escalation_reason:
                return generate_escalation_response(escalation_reason)
            if chunks:
                return generate_extractive_response(chunks, product_area, "No LLM provider available")
            return {
                'status': 'escalated',
                'response': 'No support available.',
                'justification': 'No LLM and no corpus documentation',
                'confidence': 0.0,
            }
    except Exception as e:
        # Deterministic fallback keeps the pipeline useful when the API key or
        # SDK is unavailable. The answer is extractive, so it stays grounded.
        if escalation_reason:
            return generate_escalation_response(escalation_reason)
        if chunks:
            return generate_extractive_response(chunks, product_area, str(e))
        return {
            'status': 'escalated',
            'response': 'No relevant support documentation was available. Please escalate to human support.',
            'justification': f'No grounded fallback available: {str(e)}',
            'confidence': 0.0,
        }


def generate_extractive_response(
    chunks: List[Chunk],
    product_area: str,
    fallback_reason: str = ""
) -> Dict:
    """Generate a concise grounded response directly from retrieved chunks."""
    if not chunks:
        return generate_escalation_response("No relevant support documentation found.")
        
    best_chunk = chunks[0]
    text = _clean_markdown(best_chunk.content)
    
    # Try to find a meaningful summary or first few instructions
    sentences = re.split(r'(?<=[.!?])\s+', text)
    useful = [s.strip() for s in sentences if len(s.strip()) > 20]
    
    # If it looks like a list/steps, try to preserve it
    if '1.' in text or '*' in text:
        # Simple extraction of first few lines/steps
        lines = [line.strip() for line in text.split('\n') if line.strip()]
        excerpt = " ".join(lines[:5])
    else:
        excerpt = " ".join(useful[:4]) or text[:500].strip()
    
    if len(excerpt) > 800:
        excerpt = excerpt[:797].rstrip() + "..."
    
    # Add a polite prefix
    response = f"Based on the support documentation: {excerpt}"
    
    return {
        'status': 'replied',
        'response': response,
        'justification': (
            f"Answered using grounded content from {best_chunk.heading} (File: {best_chunk.file_path}). "
            f"Note: {fallback_reason}."
        ),
        'confidence': 0.5,
    }


def _clean_markdown(text: str) -> str:
    """Remove common markdown noise for extractive fallback responses."""
    text = re.sub(r'^---\s+.*?\s+---', ' ', text, flags=re.DOTALL)
    text = re.sub(r'^\s*(title|slug|source url|article slug|last updated exact|last updated relative|breadcrumbs):.*$', ' ', text, flags=re.MULTILINE | re.IGNORECASE)
    text = re.sub(r'```.*?```', ' ', text, flags=re.DOTALL)
    text = re.sub(r'!\[[^\]]*\]\([^)]+\)', ' ', text)
    text = re.sub(r'\[([^\]]+)\]\([^)]+\)', r'\1', text)
    text = re.sub(r'[#*_`>|-]+', ' ', text)
    text = re.sub(r'\s+', ' ', text)
    return text.strip()


def generate_escalation_response(reason: str) -> Dict:
    """Generate a quick escalation response."""
    return {
        'status': 'escalated',
        'response': 'This issue requires human support. Please escalate to the support team.',
        'justification': reason,
        'confidence': 1.0,
    }


if __name__ == '__main__':
    # Test: requires ANTHROPIC_API_KEY env var
    from corpus import load_corpus, Chunk
    
    # Create dummy chunks for testing
    dummy_chunks = [
        Chunk(0, 'hackerrank', 'test.md', 'Test Creation', 'To create a test, go to Tests > Create Test > follow the wizard'),
    ]
    
    print("Testing reasoner (requires ANTHROPIC_API_KEY):")
    try:
        result = generate_grounded_response(
            issue="How do I create a new test?",
            subject="Test Creation Help",
            company="hackerrank",
            product_area="test_management",
            request_type="product_issue",
            chunks=dummy_chunks,
            escalation_reason=None
        )
        print(json.dumps(result, indent=2))
    except ValueError as e:
        print(f"Skipped: {e}")
