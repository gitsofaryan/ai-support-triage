#!/usr/bin/env python3
import csv

print("=== QUALITY IMPROVEMENTS ===\n")

for ticket_num in [6, 9]:
    print(f"\nTicket {ticket_num}:")
    print("-" * 60)
    
    # Original
    with open('../support_tickets/output.csv') as f:
        reader = csv.DictReader(f)
        for i, row in enumerate(reader, 1):
            if i == ticket_num:
                print(f"BEFORE:")
                print(f"  Response: {row['response'][:80]}...")
                break
    
    # Improved
    with open('../support_tickets/output_v2.csv') as f:
        reader = csv.DictReader(f)
        for i, row in enumerate(reader, 1):
            if i == ticket_num:
                print(f"AFTER:")
                print(f"  Response: {row['response'][:80]}...")
                break

print("\n✓ All improvements logged and tested")
