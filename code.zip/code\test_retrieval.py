#!/usr/bin/env python3
"""
Quick test script to verify improved intent-aware retrieval.
"""

from pathlib import Path
import sys
import os

# Add code/ to path
sys.path.insert(0, str(Path(__file__).parent))

from corpus import load_corpus
from retriever import retrieve_relevant_chunks
from classifier import detect_company

def test_retrieval(query: str, company_hint: str = None):
    """Test retrieval on a single query."""
    print(f"\n{'='*60}")
    print(f"Query: {query[:70]}")
    print(f"Company: {company_hint}")
    print('='*60)
    
    chunks, scorer = load_corpus()
    company = detect_company(query, "", company_hint)
    retrieval_domain = company if company in {"hackerrank", "claude", "visa"} else None
    
    retrieved, should_escalate, reason = retrieve_relevant_chunks(
        query=query,
        chunks=chunks,
        scorer=scorer,
        domain=retrieval_domain,
        top_k=3,
        confidence_threshold=0.4
    )
    
    if should_escalate:
        print(f"[ESCALATE] {reason}")
    else:
        for i, (chunk, conf) in enumerate(retrieved, 1):
            print(f"\n[{i}] Confidence: {conf:.2f}")
            print(f"    File: {chunk.file_path}")
            print(f"    Heading: {chunk.heading}")
            print(f"    Content: {chunk.content[:150]}...")

# Test the problematic tickets
if __name__ == "__main__":
    test_retrieval(
        "One of my claude conversations has some private info, i forgot to delete it",
        company_hint="Claude"
    )
    
    test_retrieval(
        "Where can I report a lost or stolen Visa card from India?",
        company_hint="Visa"
    )
    
    test_retrieval(
        "Hi there, we sent a candidate a hackerrank assessment but need extra time to complete",
        company_hint="HackerRank"
    )
