"""
Main orchestration for the support triage agent.

The agent is terminal-based: it reads tickets from CSV or stdin, applies
safety rules, retrieves local documentation, and writes predictions to CSV.
"""

import argparse
import csv
import json
import os
import sys
from pathlib import Path
from typing import Dict, List, Optional

from classifier import classify_product_area, classify_request_type, detect_company
from corpus import load_corpus
from output import write_output_csv
from reasoning import generate_escalation_response, generate_grounded_response
from retriever import retrieve_relevant_chunks
from safety import check_escalation_signals

VALID_DOMAINS = {"hackerrank", "claude", "visa"}


def row_value(row: Dict[str, str], *names: str) -> str:
    """Read a CSV value case-insensitively and tolerate spaces/underscores."""
    normalized = {
        (key or "").strip().lower().replace(" ", "_"): value
        for key, value in row.items()
    }
    for name in names:
        key = name.strip().lower().replace(" ", "_")
        value = normalized.get(key)
        if value is not None:
            return str(value)
    return ""


def typewriter_effect(text: str, speed: float = 0.01) -> None:
    """Print text with typewriter effect."""
    for char in text:
        console.out(char, end="", highlight=False)
        time.sleep(speed)
    console.out()


class SupportTriageAgent:
    """Main agent: orchestrates the full pipeline with animations."""

    def __init__(self, data_dir: Optional[str] = None, verbose: bool = True):
        self.verbose = verbose
        
        print("[Agent] Initializing Support Triage Agent...")
        self.chunks, self.scorer = load_corpus(data_dir)
        
        print(f"[Agent] Loaded {len(self.chunks)} corpus chunks")
        self.confidence_threshold = 0.4
        self.top_k = 5

    def process_ticket(
        self,
        issue: str,
        subject: str = "",
        company_hint: Optional[str] = None,
    ) -> Dict:
        """Process a single support ticket and return the output row fields."""
        if self.verbose:
            print(f"\n[cyan]Issue:[/cyan] {issue[:60]}...")

        # Company detection
        company = detect_company(issue, subject, company_hint)
        if self.verbose:
            print(f"[green][OK][/green] Company: [bold]{company}[/bold]")

        request_type = classify_request_type(issue, subject)

        # Safety check
        should_escalate, escalation_reason = check_escalation_signals(issue, subject)
        
        if should_escalate:
            if self.verbose:
                print(f"[red][WARN][/red] Safety gate: {escalation_reason}")

            response = generate_escalation_response(escalation_reason)
            response["input_issue"] = issue
            response["input_subject"] = subject
            response["input_company"] = company_hint or company
            response["product_area"] = classify_product_area(issue, subject, company)
            response["request_type"] = request_type
            return response

        if self.verbose:
            print(f"[green]✓[/green] Request type: [bold]{request_type}[/bold]")

        # Retrieval
        retrieval_domain = company if company in VALID_DOMAINS else None
            retrieved, should_escalate_retrieval, retrieval_reason = retrieve_relevant_chunks(
                query=f"{issue} {subject}",
                chunks=self.chunks,
                scorer=self.scorer,
                domain=retrieval_domain,
                top_k=self.top_k,
                confidence_threshold=self.confidence_threshold,
            )

        if self.verbose:
            confidence = retrieved[0][1] if retrieved else 0.0
            domain_label = retrieval_domain or "all"
            print(
                f"[green][OK][/green] Retrieved [bold]{len(retrieved)}[/bold] chunks "
                f"from {domain_label} (confidence: [bold]{confidence:.2f}[/bold])"
            )

        if should_escalate_retrieval:
            if self.verbose:
                print(f"[red][WARN][/red] Low confidence: {retrieval_reason}")

            response = generate_escalation_response(retrieval_reason)
            response["input_issue"] = issue
            response["input_subject"] = subject
            response["input_company"] = company_hint or company
            response["product_area"] = classify_product_area(
                issue, subject, company, [chunk for chunk, _ in retrieved]
            )
            response["request_type"] = request_type
            return response

        chunks_only = [chunk for chunk, _ in retrieved]
        product_area = classify_product_area(issue, subject, company, chunks_only)

        if self.verbose:
            print(f"[green][OK][/green] Product area: [bold]{product_area}[/bold]")

        # LLM reasoning
        response = generate_grounded_response(
                issue=issue,
                subject=subject,
                company=company,
                product_area=product_area,
                request_type=request_type,
                chunks=chunks_only,
                openrouter_key=os.environ.get('OPENROUTER_API_KEY'),
                anthropic_key=os.environ.get('ANTHROPIC_API_KEY'),
            )

        response["input_issue"] = issue
        response["input_subject"] = subject
        response["input_company"] = company_hint or company
        response["product_area"] = product_area
        response["request_type"] = request_type

        if self.verbose:
            status_color = "[green]" if response.get('status') == 'replied' else "[yellow]"
            print(f"{status_color}[OK][/{status_color.rstrip('}')[1:]}] Status: [bold]{response.get('status', 'unknown')}[/bold]")

        return response

    def process_csv(self, input_path: str, output_path: str) -> List[Dict]:
        """Process all tickets in an input CSV and write results."""
        print(f"\n[cyan]Reading from[/cyan] [bold]{input_path}[/bold]")

        tickets = []
        try:
            with open(input_path, "r", encoding="utf-8-sig", newline="") as f:
                reader = csv.DictReader(f)
                if reader.fieldnames is None:
                    print("[red]Error: empty CSV file[/red]")
                    return []
                tickets = list(reader)
            print(f"[green][OK][/green] Loaded [bold]{len(tickets)}[/bold] tickets")
        except Exception as exc:
            print(f"[red]Error reading CSV:[/red] {exc}")
            return []

        results = []
        
        # Progress bar for processing
        with Progress(
            SpinnerColumn(),
            TextColumn("[progress.description]{task.description}"),
            TextColumn("[progress.percentage]{task.percentage:>3.0f}%"),
        ) as progress:
            task = progress.add_task(f"[cyan]Processing tickets...[/cyan]", total=len(tickets))
            
            for index, ticket in enumerate(tickets, 1):
                progress.update(task, description=f"[cyan]Processing ticket {index}/{len(tickets)}[/cyan]")
                
                issue = row_value(ticket, "issue").strip()
                subject = row_value(ticket, "subject").strip()
                company = row_value(ticket, "company").strip() or None

                try:
                    results.append(self.process_ticket(issue, subject, company))
                except Exception as exc:
                    print(f"[red][ERROR] Processing ticket {index}:[/red] {exc}")
                    results.append(
                        {
                            "input_issue": issue,
                            "input_subject": subject,
                            "input_company": company or "",
                            "status": "escalated",
                            "product_area": "unknown",
                            "response": "Processing error. Please escalate to human support.",
                            "justification": str(exc),
                            "request_type": "invalid",
                        }
                    )
                
                progress.advance(task)

        print(f"\n[cyan]Writing results to[/cyan] [bold]{output_path}[/bold]")
        write_output_csv(results, output_path)
        print(f"[green][OK][/green] Results written successfully")
        
        return results

        self.confidence_threshold = 0.4
        self.top_k = 5

    def process_ticket(
        self,
        issue: str,
        subject: str = "",
        company_hint: Optional[str] = None,
    ) -> Dict:
        """Process a single support ticket and return the output row fields."""
        if self.verbose:
            print(f"\n[Ticket] Issue: {issue[:60]}...")

        company = detect_company(issue, subject, company_hint)
        if self.verbose:
            print(f"[Ticket] Detected company: {company}")

        request_type = classify_request_type(issue, subject)

        should_escalate, escalation_reason = check_escalation_signals(issue, subject)
        if should_escalate:
            if self.verbose:
                print(f"[Ticket] Safety gate triggered: {escalation_reason}")

            response = generate_escalation_response(escalation_reason)
            response["input_issue"] = issue
            response["input_subject"] = subject
            response["input_company"] = company_hint or company
            response["product_area"] = classify_product_area(issue, subject, company)
            response["request_type"] = request_type
            return response

        if self.verbose:
            print(f"[Ticket] Request type: {request_type}")

        retrieval_domain = company if company in VALID_DOMAINS else None
        retrieved, should_escalate_retrieval, retrieval_reason = retrieve_relevant_chunks(
            query=f"{issue} {subject}",
            chunks=self.chunks,
            scorer=self.scorer,
            domain=retrieval_domain,
            top_k=self.top_k,
            confidence_threshold=self.confidence_threshold,
        )

        if self.verbose:
            confidence = retrieved[0][1] if retrieved else 0.0
            domain_label = retrieval_domain or "all"
            print(
                f"[Ticket] Retrieved {len(retrieved)} chunks "
                f"from {domain_label} (confidence: {confidence:.2f})"
            )

        if should_escalate_retrieval:
            if self.verbose:
                print(f"[Ticket] Low confidence retrieval: {retrieval_reason}")

            response = generate_escalation_response(retrieval_reason)
            response["input_issue"] = issue
            response["input_subject"] = subject
            response["input_company"] = company_hint or company
            response["product_area"] = classify_product_area(
                issue, subject, company, [chunk for chunk, _ in retrieved]
            )
            response["request_type"] = request_type
            return response

        chunks_only = [chunk for chunk, _ in retrieved]
        product_area = classify_product_area(issue, subject, company, chunks_only)

        if self.verbose:
            print(f"[Ticket] Product area: {product_area}")
            print("[Ticket] Generating grounded response...")

        response = generate_grounded_response(
            issue=issue,
            subject=subject,
            company=company,
            product_area=product_area,
            request_type=request_type,
            chunks=chunks_only,
            openrouter_key=os.environ.get('OPENROUTER_API_KEY'),
            anthropic_key=os.environ.get('ANTHROPIC_API_KEY'),
        )

        response["input_issue"] = issue
        response["input_subject"] = subject
        response["input_company"] = company_hint or company
        response["product_area"] = product_area
        response["request_type"] = request_type

        if self.verbose:
            print(f"[Ticket] Status: {response.get('status', 'unknown')}")

        return response

    def process_csv(self, input_path: str, output_path: str) -> List[Dict]:
        """Process all tickets in an input CSV and write results."""
        print(f"\n[CSV] Reading from {input_path}")

        tickets = []
        try:
            with open(input_path, "r", encoding="utf-8-sig", newline="") as f:
                reader = csv.DictReader(f)
                if reader.fieldnames is None:
                    print("[CSV] Error: empty CSV file")
                    return []
                tickets = list(reader)
            print(f"[CSV] Loaded {len(tickets)} tickets")
        except Exception as exc:
            print(f"[CSV] Error reading CSV: {exc}")
            return []

        results = []
        for index, ticket in enumerate(tickets, 1):
            print(f"\n[CSV] Processing ticket {index}/{len(tickets)}")

            issue = row_value(ticket, "issue").strip()
            subject = row_value(ticket, "subject").strip()
            company = row_value(ticket, "company").strip() or None

            try:
                results.append(self.process_ticket(issue, subject, company))
            except Exception as exc:
                print(f"[CSV] Error processing ticket {index}: {exc}")
                results.append(
                    {
                        "input_issue": issue,
                        "input_subject": subject,
                        "input_company": company or "",
                        "status": "escalated",
                        "product_area": "unknown",
                        "response": "Processing error. Please escalate to human support.",
                        "justification": str(exc),
                        "request_type": "invalid",
                    }
                )

        print(f"\n[CSV] Writing results to {output_path}")
        write_output_csv(results, output_path)
        return results


def main() -> None:
    parser = argparse.ArgumentParser(
        description="Support Triage Agent: process support tickets using local RAG",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""Examples:
  python main.py --file ../support_tickets/support_tickets.csv --output ../support_tickets/output.csv
  python main.py --ticket "How do I create a test?" --company HackerRank
""",
    )

    parser.add_argument("--file", type=str, help="Input CSV file path")
    parser.add_argument("--output", type=str, help="Output CSV file path")
    parser.add_argument("--ticket", type=str, help="Single ticket to process")
    parser.add_argument("--company", type=str, help="Company hint for a single ticket")
    parser.add_argument("--data-dir", type=str, help="Path to data/ directory")
    parser.add_argument("--quiet", action="store_true", help="Suppress ticket-level output")

    args = parser.parse_args()
    agent = SupportTriageAgent(data_dir=args.data_dir, verbose=not args.quiet)

    if args.file:
        input_path = args.file
        output_path = args.output or "output.csv"

        if not Path(input_path).exists():
            print(f"[red]Error: Input file not found:[/red] {input_path}")
            sys.exit(1)

        results = agent.process_csv(input_path, output_path)
        print(f"\n[green][OK][/green] Processed [bold]{len(results)}[/bold] tickets")
        print(f"[green][OK][/green] Output written to [bold]{output_path}[/bold]")
    elif args.ticket:
        result = agent.process_ticket(args.ticket, subject="", company_hint=args.company)
        print("\n[cyan]Result:[/cyan]")
        print(json.dumps(result, indent=2))
    else:
        print("\n[cyan]Interactive Mode[/cyan]")
        print("Enter support tickets, or 'quit' to exit.\n")

        while True:
            issue = input("[cyan]Issue:[/cyan] ").strip()
            if issue.lower() in {"quit", "exit", "q"}:
                break

            subject = input("[cyan]Subject (optional):[/cyan] ").strip()
            company = input("[cyan]Company (HackerRank/Claude/Visa, optional):[/cyan] ").strip()

            result = agent.process_ticket(issue, subject, company or None)
            print("\n[cyan]Response:[/cyan]")
            print(f"Status: [bold]{result.get('status')}[/bold]")
            print(f"Product Area: [bold]{result.get('product_area')}[/bold]")
            print(f"Request Type: [bold]{result.get('request_type')}[/bold]")
            print(f"\nResponse: {result.get('response')}")
            print(f"\nJustification: {result.get('justification')}")


if __name__ == "__main__":
    main()
