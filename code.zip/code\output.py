"""
Output: Write results to CSV.
"""

import csv
from pathlib import Path
from typing import List, Dict, Any


def write_output_csv(
    results: List[Dict[str, Any]],
    output_path: str,
    input_columns: List[str] = None
) -> None:
    """
    Write results to output CSV.
    
    Args:
        results: List of result dicts, each with keys:
            - input_issue, input_subject, input_company (from input)
            - status, product_area, response, justification, request_type (output)
        output_path: Path to write CSV
        input_columns: Names of input columns to include
    """
    if not results:
        print(f"[Output] No results to write")
        return
    
    if input_columns is None:
        input_columns = ['issue', 'subject', 'company']
    
    output_columns = ['response', 'product_area', 'status', 'request_type', 'justification']
    
    # Build column order: input columns first, then output columns
    all_columns = input_columns + output_columns
    
    print(f"[Output] Writing {len(results)} rows to {output_path}")
    
    try:
        Path(output_path).parent.mkdir(parents=True, exist_ok=True)
        with open(output_path, 'w', newline='', encoding='utf-8') as f:
            writer = csv.DictWriter(f, fieldnames=all_columns)
            writer.writeheader()
            
            for result in results:
                row = {}
                
                # Add input columns (preserve original input)
                for col in input_columns:
                    input_key = f"input_{col}"
                    row[col] = result.get(input_key, "")
                
                # Add output columns
                for col in output_columns:
                    row[col] = result.get(col, "")
                
                writer.writerow(row)
        
        print(f"[Output] Successfully wrote {len(results)} rows")
    
    except Exception as e:
        print(f"[Output] Error writing CSV: {e}")
        raise


def validate_result(result: Dict[str, Any]) -> bool:
    """Check if a result has all required fields."""
    required_fields = [
        'status', 'product_area', 'response', 'justification', 'request_type'
    ]
    return all(field in result for field in required_fields)


if __name__ == '__main__':
    # Test: write sample CSV
    sample_results = [
        {
            'input_issue': 'How do I create a test?',
            'input_subject': 'Test Creation',
            'input_company': 'HackerRank',
            'status': 'replied',
            'product_area': 'test_management',
            'response': 'To create a test, go to Tests > Create Test',
            'justification': 'Matched in test creation docs',
            'request_type': 'product_issue',
        },
        {
            'input_issue': 'Please increase my score',
            'input_subject': 'Score Dispute',
            'input_company': 'HackerRank',
            'status': 'escalated',
            'product_area': 'assessment_integrity',
            'response': 'Please escalate to human support',
            'justification': 'Score disputes require appeals board',
            'request_type': 'invalid',
        },
    ]
    
    write_output_csv(sample_results, 'test_output.csv')
    print("\nTest output created at test_output.csv")
