"""
Main orchestration for the support triage agent.

The agent is terminal-based: it reads tickets from CSV or stdin, applies
safety rules, retrieves local documentation, and writes predictions to CSV.
"""

import argparse
import csv
import json
import os
import sys
import time
from pathlib import Path
from typing import Dict, List, Optional
from dotenv import load_dotenv

load_dotenv()

from classifier import classify_product_area, classify_request_type, detect_company
from corpus import load_corpus
from output import write_output_csv
from reasoning import generate_escalation_response, generate_grounded_response
from retriever import retrieve_relevant_chunks
from safety import check_escalation_signals

from rich.console import Console
from halo import Halo
from tqdm import tqdm

console = Console()

VALID_DOMAINS = {"hackerrank", "claude", "visa"}


def row_value(row: Dict[str, str], *names: str) -> str:
    """Read a CSV value case-insensitively and tolerate spaces/underscores."""
    normalized = {
        (key or "").strip().lower().replace(" ", "_"): value
        for key, value in row.items()
    }
    for name in names:
        key = name.strip().lower().replace(" ", "_")
        value = normalized.get(key)
        if value is not None:
            return str(value)
    return ""


def typewriter_effect(text: str, speed: float = 0.01) -> None:
    """Print text with typewriter effect."""
    for char in text:
        sys.stdout.write(char)
        sys.stdout.flush()
        time.sleep(speed)
    sys.stdout.write("\n")


class SupportTriageAgent:
    """Main agent: orchestrates the full pipeline."""

    def __init__(self, data_dir: Optional[str] = None, verbose: bool = True):
        self.verbose = verbose
        console.print("[bold blue][Agent][/bold blue] Initializing Support Triage Agent...")

        with Halo(text='Loading corpus...', spinner='dots') if self.verbose else open(os.devnull, 'w'):
            self.chunks, self.scorer = load_corpus(data_dir)
        
        console.print(f"[bold blue][Agent][/bold blue] Loaded [bold green]{len(self.chunks)}[/bold green] corpus chunks")
        self.confidence_threshold = 0.4
        self.top_k = 5

    def process_ticket(
        self,
        issue: str,
        subject: str = "",
        company_hint: Optional[str] = None,
    ) -> Dict:
        """Process a single support ticket and return the output row fields."""
        if self.verbose:
            console.print(f"\n[bold cyan][Ticket][/bold cyan] Issue: {issue[:60]}...")

        company = detect_company(issue, subject, company_hint)
        if self.verbose:
            console.print(f"[bold cyan][Ticket][/bold cyan] Detected company: [bold yellow]{company}[/bold yellow]")

        request_type = classify_request_type(issue, subject)

        should_escalate, escalation_reason = check_escalation_signals(issue, subject)
        if should_escalate:
            if self.verbose:
                console.print(f"[bold cyan][Ticket][/bold cyan] [bold red]Safety gate triggered:[/bold red] {escalation_reason}")

            response = generate_escalation_response(escalation_reason)
            response["input_issue"] = issue
            response["input_subject"] = subject
            response["input_company"] = company_hint or company
            response["product_area"] = classify_product_area(issue, subject, company)
            response["request_type"] = request_type
            return response

        if self.verbose:
            console.print(f"[bold cyan][Ticket][/bold cyan] Request type: [bold]{request_type}[/bold]")

        retrieval_domain = company if company in VALID_DOMAINS else None
        
        spinner = Halo(text='Retrieving relevant documents...', spinner='arc') if self.verbose else None
        if spinner: spinner.start()
        
        retrieved, should_escalate_retrieval, retrieval_reason = retrieve_relevant_chunks(
            query=f"{issue} {subject}",
            chunks=self.chunks,
            scorer=self.scorer,
            domain=retrieval_domain,
            top_k=self.top_k,
            confidence_threshold=self.confidence_threshold,
        )
        
        if spinner: spinner.succeed('Documents retrieved')

        if self.verbose:
            confidence = retrieved[0][1] if retrieved else 0.0
            domain_label = retrieval_domain or "all"
            console.print(
                f"[bold cyan][Ticket][/bold cyan] Retrieved [bold green]{len(retrieved)}[/bold green] chunks "
                f"from {domain_label} (confidence: {confidence:.2f})"
            )

        if should_escalate_retrieval:
            if self.verbose:
                console.print(f"[bold cyan][Ticket][/bold cyan] [bold yellow]Low confidence retrieval:[/bold yellow] {retrieval_reason}")

            response = generate_escalation_response(retrieval_reason)
            response["input_issue"] = issue
            response["input_subject"] = subject
            response["input_company"] = company_hint or company
            response["product_area"] = classify_product_area(
                issue, subject, company, [item[0] for item in retrieved]
            )
            response["request_type"] = request_type
            return response

        chunks_only = [item[0] for item in retrieved]
        product_area = classify_product_area(issue, subject, company, chunks_only)

        if self.verbose:
            console.print(f"[bold cyan][Ticket][/bold cyan] Product area: [bold]{product_area}[/bold]")
            
        gen_spinner = Halo(text='Generating grounded response...', spinner='dots') if self.verbose else None
        if gen_spinner: gen_spinner.start()

        response = generate_grounded_response(
            issue=issue,
            subject=subject,
            company=company,
            product_area=product_area,
            request_type=request_type,
            chunks=chunks_only,
            openrouter_key=os.environ.get('OPENROUTER_API_KEY'),
            anthropic_key=os.environ.get('ANTHROPIC_API_KEY'),
        )
        
        if gen_spinner: gen_spinner.succeed('Response generated')

        response["input_issue"] = issue
        response["input_subject"] = subject
        response["input_company"] = company_hint or company
        response["product_area"] = product_area
        response["request_type"] = request_type

        if self.verbose:
            status_color = "green" if response.get('status') == 'replied' else "yellow"
            console.print(f"[bold cyan][Ticket][/bold cyan] Status: [bold {status_color}]{response.get('status', 'unknown')}[/bold {status_color}]")

        return response

    def process_csv(self, input_path: str, output_path: str) -> List[Dict]:
        """Process all tickets in an input CSV and write results."""
        console.print(f"\n[bold magenta][CSV][/bold magenta] Reading from [u]{input_path}[/u]")

        tickets = []
        try:
            with open(input_path, "r", encoding="utf-8-sig", newline="") as f:
                reader = csv.DictReader(f)
                if reader.fieldnames is None:
                    console.print("[bold red][CSV] Error: empty CSV file[/bold red]")
                    return []
                tickets = list(reader)
            console.print(f"[bold magenta][CSV][/bold magenta] Loaded [bold green]{len(tickets)}[/bold green] tickets")
        except Exception as exc:
            console.print(f"[bold red][CSV] Error reading CSV:[/bold red] {exc}")
            return []

        results = []
        
        # Turn off verbose for individual tickets to keep the progress bar clean
        original_verbose = self.verbose
        self.verbose = False
        
        for index, ticket in enumerate(tqdm(tickets, desc="Processing Tickets", unit="ticket")):
            issue = row_value(ticket, "issue").strip()
            subject = row_value(ticket, "subject").strip()
            company = row_value(ticket, "company").strip() or None

            try:
                results.append(self.process_ticket(issue, subject, company))
            except Exception as exc:
                results.append(
                    {
                        "input_issue": issue,
                        "input_subject": subject,
                        "input_company": company or "",
                        "status": "escalated",
                        "product_area": "unknown",
                        "response": "Processing error. Please escalate to human support.",
                        "justification": str(exc),
                        "request_type": "invalid",
                    }
                )

        self.verbose = original_verbose
        console.print(f"\n[bold magenta][CSV][/bold magenta] Writing results to [u]{output_path}[/u]")
        write_output_csv(results, output_path)
        return results


def main() -> None:
    parser = argparse.ArgumentParser(
        description="Support Triage Agent: process support tickets using local RAG",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""Examples:
  python main.py --file ../support_tickets/support_tickets.csv --output ../support_tickets/output.csv
  python main.py --ticket "How do I create a test?" --company HackerRank
""",
    )

    parser.add_argument("--file", type=str, help="Input CSV file path")
    parser.add_argument("--output", type=str, help="Output CSV file path")
    parser.add_argument("--ticket", type=str, help="Single ticket to process")
    parser.add_argument("--company", type=str, help="Company hint for a single ticket")
    parser.add_argument("--data-dir", type=str, help="Path to data/ directory")
    parser.add_argument("--quiet", action="store_true", help="Suppress ticket-level output")

    args = parser.parse_args()
    agent = SupportTriageAgent(data_dir=args.data_dir, verbose=not args.quiet)

    if args.file:
        input_path = args.file
        output_path = args.output or "output.csv"

        if not Path(input_path).exists():
            console.print(f"[bold red]Error: Input file not found:[/bold red] {input_path}")
            sys.exit(1)

        results = agent.process_csv(input_path, output_path)
        console.print(f"\n[bold green][OK][/bold green] Processed {len(results)} tickets")
        console.print(f"[bold green][OK][/bold green] Output written to {output_path}")
    elif args.ticket:
        result = agent.process_ticket(args.ticket, subject="", company_hint=args.company)
        console.print("\n[bold cyan][Result][/bold cyan]")
        console.print(json.dumps(result, indent=2))
    else:
        console.print("\n[bold underline]Interactive Mode[/bold underline]")
        console.print("Enter support tickets, or 'quit' to exit.")

        while True:
            issue = input("\nIssue: ").strip()
            if issue.lower() in {"quit", "exit", "q"}:
                break

            subject = input("Subject (optional): ").strip()
            company = input("Company (HackerRank/Claude/Visa, optional): ").strip()

            result = agent.process_ticket(issue, subject, company or None)
            console.print("\n[bold cyan][Response][/bold cyan]")
            console.print(f"Status: [bold]{result.get('status')}[/bold]")
            console.print(f"Product Area: [bold]{result.get('product_area')}[/bold]")
            console.print(f"Request Type: [bold]{result.get('request_type')}[/bold]")
            console.print("Response: ", end="")
            typewriter_effect(result.get('response', ''))
            console.print(f"Justification: {result.get('justification')}")


if __name__ == "__main__":
    main()
