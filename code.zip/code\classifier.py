"""
Classifier: Detect company and classify product areas.
"""

import re
from typing import Optional, List
from corpus import Chunk


COMPANY_KEYWORDS = {
    'hackerrank': [
        'test', 'candidate', 'assessment', 'role', 'screen', 'interview',
        'mock interview', 'hackerrank', 'hr', 'hiring', 'recruiter',
        'question', 'library', 'variant', 'engage', 'invite'
    ],
    'claude': [
        'claude', 'api', 'model', 'token', 'context', 'conversation',
        'desktop', 'chat', 'prompt', 'anthropic', 'bedrock',
        'team workspace', 'subscription'
    ],
    'visa': [
        'card', 'payment', 'visa', 'credit', 'debit', 'transaction',
        'merchant', 'dispute', 'fraud', 'cheque', 'traveller'
    ],
}

PRODUCT_AREA_KEYWORDS = {
    'test_management': ['test', 'create', 'variant', 'archive', 'clone', 'delete'],
    'candidate_management': ['candidate', 'invite', 'reinvite', 'extra time', 'accommodation'],
    'interview_management': ['mock interview', 'live interview', 'interviewer', 'room'],
    'account_management': ['account', 'password', 'login', 'user', 'team', 'delete account'],
    'assessment_integrity': ['leaked', 'question', 'leakage', 'duplicate'],
    'api_usage': ['api', 'key', 'token', 'context window', 'rate limit', 'quota'],
    'billing': ['billing', 'pricing', 'subscription', 'plan', 'payment'],
    'privacy_data': ['data', 'privacy', 'GDPR', 'export', 'retention', 'delete'],
    'conversation_management': ['conversation', 'chat', 'delete', 'rename', 'share'],
    'card_management': ['card', 'lost', 'stolen', 'replace', 'PIN', 'block'],
    'payment_fraud': ['fraud', 'dispute', 'unauthorized', 'chargeback', 'transaction'],
}


class Classifier:
    """Classifies company and product area."""
    
    @staticmethod
    def detect_company(
        issue: str,
        subject: str = "",
        company_hint: Optional[str] = None
    ) -> str:
        """
        Detect which company/domain this issue belongs to.
        
        Returns:
            'hackerrank', 'claude', 'visa', or 'unknown'
        """
        # If hint is provided and valid, use it
        if company_hint and company_hint.lower() in COMPANY_KEYWORDS:
            return company_hint.lower()
        
        combined_text = f"{issue} {subject}".lower()
        
        # Score each domain
        scores = {}
        for domain, keywords in COMPANY_KEYWORDS.items():
            score = sum(1 for kw in keywords if kw in combined_text)
            scores[domain] = score
        
        # Return highest scoring domain (or unknown if all zero)
        if max(scores.values()) > 0:
            return max(scores, key=scores.get)
        
        return 'unknown'
    
    @staticmethod
    def classify_product_area(
        issue: str,
        subject: str = "",
        company: str = 'unknown',
        retrieved_chunks: Optional[List[Chunk]] = None
    ) -> str:
        """
        Classify the product area (category) for this issue.
        
        Returns:
            e.g., 'test_management', 'billing', 'api_usage', etc.
        """
        combined_text = f"{issue} {subject}".lower()
        
        # Score each product area
        scores = {}
        for area, keywords in PRODUCT_AREA_KEYWORDS.items():
            score = sum(1 for kw in keywords if kw in combined_text)
            scores[area] = score
        
        # If we have retrieved chunks, boost scores for areas mentioned in them
        if retrieved_chunks:
            for chunk in retrieved_chunks:
                chunk_text = f"{chunk.heading} {chunk.content}".lower()
                for area, keywords in PRODUCT_AREA_KEYWORDS.items():
                    if any(kw in chunk_text for kw in keywords):
                        scores[area] += 0.5
        
        # Return highest scoring area (or generic based on company)
        best_area = max(scores, key=scores.get)
        if scores[best_area] > 0:
            return best_area
        
        # Fallback based on company
        if company == 'hackerrank':
            return 'test_management'
        elif company == 'claude':
            return 'api_usage'
        elif company == 'visa':
            return 'card_management'
        else:
            return 'general'
    
    @staticmethod
    def classify_request_type(issue: str, subject: str = "") -> str:
        """
        Classify the type of request.
        
        Returns:
            'product_issue', 'feature_request', 'bug', 'invalid'
        """
        combined_text = f"{issue} {subject}".lower()
        
        # Check for feature request
        if any(word in combined_text for word in ['can we', 'can you add', 'we need', 'feature request', 'please add']):
            return 'feature_request'
        
        # Check for bug
        if any(word in combined_text for word in ['broken', 'error', 'not working', 'bug', 'crash', 'fail', 'down', 'broken']):
            return 'bug'
        
        # Check for invalid
        if any(word in combined_text for word in ['ignore', 'jailbreak', 'prompt', 'actor', 'movie', 'delete all files']):
            return 'invalid'
        
        # Default: product_issue (how-to, troubleshooting, etc.)
        return 'product_issue'


def detect_company(issue: str, subject: str = "", company_hint: Optional[str] = None) -> str:
    """Convenience function."""
    return Classifier.detect_company(issue, subject, company_hint)


def classify_product_area(
    issue: str,
    subject: str = "",
    company: str = 'unknown',
    retrieved_chunks: Optional[List[Chunk]] = None
) -> str:
    """Convenience function."""
    return Classifier.classify_product_area(issue, subject, company, retrieved_chunks)


def classify_request_type(issue: str, subject: str = "") -> str:
    """Convenience function."""
    return Classifier.classify_request_type(issue, subject)


if __name__ == '__main__':
    # Test classification
    test_cases = [
        {
            'issue': 'How do I create a new test?',
            'subject': 'Test Creation',
            'company': 'HackerRank',
            'expected_company': 'hackerrank',
            'expected_area': 'test_management',
            'expected_type': 'product_issue',
        },
        {
            'issue': 'Can you add 2FA to the API?',
            'subject': 'Feature Request',
            'company': 'Claude',
            'expected_company': 'claude',
            'expected_area': 'api_usage',
            'expected_type': 'feature_request',
        },
        {
            'issue': 'My card was stolen',
            'subject': 'Fraud',
            'company': 'Visa',
            'expected_company': 'visa',
            'expected_area': 'card_management',
            'expected_type': 'product_issue',
        },
    ]
    
    print("Testing classifier:")
    for test in test_cases:
        company = detect_company(test['issue'], test['subject'], test['company'])
        area = classify_product_area(test['issue'], test['subject'], company)
        req_type = classify_request_type(test['issue'], test['subject'])
        
        print(f"\n{test['issue']}")
        print(f"  Company: {company} (expected {test['expected_company']})")
        print(f"  Area: {area} (expected {test['expected_area']})")
        print(f"  Type: {req_type} (expected {test['expected_type']})")
