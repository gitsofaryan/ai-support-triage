"""
Corpus Loader & Indexer

Loads all markdown files from data/hackerrank, data/claude, data/visa.
Chunks by section headings (##).
Returns indexed chunks for BM25 retrieval.
"""

import os
import re
from pathlib import Path
from typing import List, Dict, Tuple
from collections import Counter
import math


class Chunk:
    """Represents a single chunk of corpus text."""
    
    def __init__(self, chunk_id: int, domain: str, file_path: str, 
                 heading: str, content: str):
        self.chunk_id = chunk_id
        self.domain = domain  # 'hackerrank', 'claude', 'visa'
        self.file_path = file_path
        self.heading = heading
        self.content = content
        self.tokens = self.tokenize(f"{domain} {file_path} {heading} {content}")
    
    def tokenize(self, text: str) -> List[str]:
        """Simple tokenization: lowercase, split on whitespace + punctuation."""
        text = text.lower()
        tokens = re.findall(r'\b\w+\b', text)
        return tokens
    
    def __repr__(self):
        return f"Chunk({self.chunk_id}, {self.domain}, {self.heading[:30]}...)"


class CorpusLoader:
    """Loads and chunks markdown corpus."""
    
    def __init__(self, data_dir: str = None):
        if data_dir is None:
            data_dir = os.path.join(
                os.path.dirname(os.path.dirname(__file__)), 
                'data'
            )
        self.data_dir = data_dir
        self.chunks: List[Chunk] = []
        self.chunk_index: Dict[str, List[int]] = {}  # word -> chunk_ids
        self.domain_stats = {'hackerrank': 0, 'claude': 0, 'visa': 0}
    
    def load(self) -> List[Chunk]:
        """Load all markdown files and chunk them."""
        print(f"[Corpus] Loading from {self.data_dir}")
        
        chunk_id = 0
        
        # Load each domain
        for domain in ['hackerrank', 'claude', 'visa']:
            domain_path = os.path.join(self.data_dir, domain)
            if not os.path.exists(domain_path):
                print(f"[Corpus] Warning: {domain_path} not found, skipping")
                continue
            
            print(f"[Corpus] Loading {domain}...")
            for file_path in self._walk_md_files(domain_path):
                # Get relative path for clarity
                rel_path = os.path.relpath(file_path, self.data_dir)
                
                # Read file
                try:
                    with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
                        content = f.read()
                except Exception as e:
                    print(f"[Corpus] Error reading {file_path}: {e}")
                    continue
                
                # Chunk by section headings (##)
                new_chunks = self._chunk_by_headings(
                    content, domain, rel_path
                )
                
                for chunk_text, heading in new_chunks:
                    chunk = Chunk(chunk_id, domain, rel_path, heading, chunk_text)
                    self.chunks.append(chunk)
                    chunk_id += 1
                    self.domain_stats[domain] += 1
                    
                    # Index tokens
                    for token in set(chunk.tokens):  # unique tokens only
                        if token not in self.chunk_index:
                            self.chunk_index[token] = []
                        self.chunk_index[token].append(chunk.chunk_id)
        
        print(f"[Corpus] Loaded {len(self.chunks)} chunks")
        print(f"[Corpus] Domain stats: {self.domain_stats}")
        return self.chunks
    
    def _walk_md_files(self, root_dir: str) -> List[str]:
        """Walk directory and collect all .md files."""
        md_files = []
        for root, dirs, files in os.walk(root_dir):
            for file in files:
                if file.endswith('.md'):
                    md_files.append(os.path.join(root, file))
        return sorted(md_files)
    
    def _chunk_by_headings(self, content: str, domain: str, 
                           file_path: str) -> List[Tuple[str, str]]:
        """
        Split content by ## headings.
        Returns list of (chunk_text, heading) tuples.
        """
        chunks = []
        
        # Split by ## (markdown h2)
        sections = re.split(r'^## ', content, flags=re.MULTILINE)
        
        # First section might have no heading (frontmatter, etc.)
        if sections[0].strip():
            heading = f"[{domain}] {file_path} (intro)"
            chunks.append((sections[0], heading))
        
        # Remaining sections have headings
        for section in sections[1:]:
            lines = section.split('\n', 1)
            if len(lines) >= 2:
                heading_text = lines[0].strip()
                chunk_text = lines[1]
                if chunk_text.strip():
                    full_heading = f"[{domain}] {file_path} >> {heading_text}"
                    chunks.append((chunk_text, full_heading))
        
        return chunks
    
    def get_chunks(self) -> List[Chunk]:
        """Return all chunks."""
        return self.chunks
    
    def get_chunks_by_domain(self, domain: str) -> List[Chunk]:
        """Get chunks for a specific domain."""
        return [c for c in self.chunks if c.domain == domain]
    
    def search_tokens(self, tokens: List[str]) -> Dict[int, int]:
        """
        Quick token-based search.
        Returns {chunk_id: match_count}.
        """
        matches = {}
        for token in tokens:
            if token in self.chunk_index:
                for chunk_id in self.chunk_index[token]:
                    matches[chunk_id] = matches.get(chunk_id, 0) + 1
        return matches


class BM25Scorer:
    """BM25 scoring for chunks."""
    
    def __init__(self, chunks: List[Chunk], k1: float = 1.5, b: float = 0.75):
        self.chunks = chunks
        self.k1 = k1
        self.b = b
        
        # Compute IDF for each unique token
        self.token_frequencies = Counter()
        self.doc_count = len(chunks)
        self.avg_doc_len = 0
        
        for chunk in chunks:
            self.token_frequencies.update(set(chunk.tokens))
            self.avg_doc_len += len(chunk.tokens)
        
        if self.doc_count > 0:
            self.avg_doc_len /= self.doc_count
    
    def score(self, query_tokens: List[str], chunk: Chunk) -> float:
        """Compute BM25 score for query against chunk."""
        score = 0.0
        doc_len = len(chunk.tokens)
        chunk_token_freq = Counter(chunk.tokens)
        
        for token in query_tokens:
            # IDF calculation
            if self.token_frequencies[token] > 0:
                idf = math.log(
                    (self.doc_count - self.token_frequencies[token] + 0.5) /
                    (self.token_frequencies[token] + 0.5) + 1.0
                )
            else:
                continue
            
            # BM25 formula
            freq = chunk_token_freq.get(token, 0)
            numerator = freq * (self.k1 + 1)
            denominator = freq + self.k1 * (1 - self.b + self.b * doc_len / (self.avg_doc_len + 1e-6))
            
            score += idf * (numerator / denominator)
        
        return score


def load_corpus(data_dir: str = None) -> Tuple[List[Chunk], BM25Scorer]:
    """
    Load corpus and return chunks + scorer.
    
    Usage:
        chunks, scorer = load_corpus()
        scores = [scorer.score(query_tokens, c) for c in chunks]
    """
    loader = CorpusLoader(data_dir)
    chunks = loader.load()
    scorer = BM25Scorer(chunks)
    return chunks, scorer


if __name__ == '__main__':
    # Test: load corpus and print stats
    chunks, scorer = load_corpus()
    print(f"\nTotal chunks: {len(chunks)}")
    print(f"Average chunk doc length: {scorer.avg_doc_len:.1f} tokens")
    
    # Sample chunks
    print("\nSample chunks:")
    for i in range(min(5, len(chunks))):
        c = chunks[i]
        print(f"  {i}: {c.heading} ({len(c.tokens)} tokens)")
    
    # Test scoring
    print("\nTest BM25 scoring:")
    query = "test management how to create test"
    query_tokens = re.findall(r'\b\w+\b', query.lower())
    scores = [(i, scorer.score(query_tokens, c)) for i, c in enumerate(chunks)]
    scores.sort(key=lambda x: x[1], reverse=True)
    
    print(f"Query: {query}")
    print(f"Top-5 results:")
    for chunk_id, score in scores[:5]:
        c = chunks[chunk_id]
        print(f"  {chunk_id}: {score:.2f} - {c.heading}")
