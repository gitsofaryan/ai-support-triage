"""
Retriever: BM25-based chunk retrieval from corpus.

Given a query (issue + subject), retrieves top-K most relevant chunks
with BM25 scoring and intent-aware reranking.

Intent boost maps high-value query terms to document content, prioritizing
exact matches over generic FAQ content.
"""

import re
from typing import List, Dict, Tuple, Optional
from corpus import Chunk, BM25Scorer

# Intent boost mapping: query term -> boost multiplier and chunk term patterns
INTENT_BOOST_MAP = {
    'delete': {
        'boost': 2.5,
        'chunk_patterns': ['delete', 'remove', 'purge', 'clear', 'erase'],
        'bad_patterns': ['crisis', 'emergency', 'helpline'],  # Penalize if these appear
    },
    'private': {
        'boost': 2.0,
        'chunk_patterns': ['privacy', 'private', 'confidential', 'secure', 'data protection'],
        'bad_patterns': ['crisis', 'emergency'],
    },
    'lost': {
        'boost': 2.5,
        'chunk_patterns': ['lost', 'stolen', 'missing', 'report loss', 'block card', 'freeze'],
        'bad_patterns': ['login', 'password', 'account access', 'faq'],
    },
    'stolen': {
        'boost': 2.5,
        'chunk_patterns': ['stolen', 'lost', 'fraud', 'dispute', 'block', 'report'],
        'bad_patterns': ['login', 'password'],
    },
    'extra time': {
        'boost': 2.0,
        'chunk_patterns': ['extra time', 'time extension', 'pause', 'reschedule', 'reinvite'],
        'bad_patterns': ['faq', 'general help'],
    },
    'reschedule': {
        'boost': 2.0,
        'chunk_patterns': ['reschedule', 'extra time', 'pause', 'postpone'],
        'bad_patterns': [],
    },
}


class Retriever:
    """Retrieves relevant chunks given a query with intent-aware reranking."""
    
    def __init__(self, chunks: List[Chunk], scorer: BM25Scorer, 
                 confidence_threshold: float = 0.4):
        self.chunks = chunks
        self.scorer = scorer
        self.confidence_threshold = confidence_threshold
    
    def _calculate_intent_boost(self, query: str, chunk: Chunk) -> float:
        """
        Calculate intent boost multiplier for a chunk based on query intent.
        
        If query contains high-value terms (delete, lost, stolen, etc.),
        boost chunks that contain matching patterns and penalize if they
        contain "bad" patterns (generic FAQ, crisis helpline, etc).
        
        Returns multiplier >= 1.0 (1.0 means no boost).
        """
        query_lower = query.lower()
        chunk_text = (chunk.heading + " " + chunk.content).lower()
        
        multiplier = 1.0
        
        for intent_term, config in INTENT_BOOST_MAP.items():
            if intent_term in query_lower:
                # Check if chunk contains good patterns
                good_match = any(
                    pattern in chunk_text 
                    for pattern in config['chunk_patterns']
                )
                if good_match:
                    multiplier *= config['boost']
                
                # Penalize if chunk contains bad patterns
                bad_match = any(
                    pattern in chunk_text 
                    for pattern in config.get('bad_patterns', [])
                )
                if bad_match:
                    multiplier *= 0.3  # Significant penalty
        
        return multiplier
    
    def retrieve(self, query: str, domain: Optional[str] = None, 
                 top_k: int = 5) -> List[Tuple[Chunk, float, float]]:
        """
        Retrieve top-K chunks relevant to query with intent-aware reranking.
        
        Args:
            query: Issue text to search for
            domain: Filter to domain ('hackerrank', 'claude', 'visa') or None for all
            top_k: Number of results to return
        
        Returns:
            List of (chunk, score, confidence) tuples, sorted by reranked score desc
            where confidence is a bounded absolute BM25 signal.
        """
        # Tokenize query
        query_tokens = self._tokenize(query)
        if not query_tokens:
            return []
        
        # Filter chunks by domain if specified
        candidate_chunks = self.chunks
        if domain:
            candidate_chunks = [c for c in self.chunks if c.domain == domain]
        
        if not candidate_chunks:
            return []
        
        # Score each chunk with BM25
        scores = []
        for chunk in candidate_chunks:
            bm25_score = self.scorer.score(query_tokens, chunk)
            
            # Apply intent boost to rerank
            intent_multiplier = self._calculate_intent_boost(query, chunk)
            reranked_score = bm25_score * intent_multiplier
            
            scores.append((chunk, reranked_score))
        
        # Sort by reranked score descending
        scores.sort(key=lambda x: x[1], reverse=True)
        
        # Calculate confidence (using reranked score) and return top-K
        results = []
        for chunk, reranked_score in scores[:top_k]:
            confidence = min(reranked_score / 25.0, 1.0) if reranked_score > 0 else 0.0
            results.append((chunk, reranked_score, confidence))
        
        return results
    
    def _tokenize(self, text: str) -> List[str]:
        """Tokenize query: lowercase, remove punctuation."""
        text = text.lower()
        tokens = re.findall(r'\b\w+\b', text)
        # Remove very short tokens and common stopwords
        stopwords = {
            'the', 'a', 'an', 'and', 'or', 'is', 'are', 'was', 'were',
            'be', 'been', 'being', 'have', 'has', 'had', 'do', 'does',
            'did', 'will', 'would', 'could', 'should', 'may', 'might',
            'can', 'what', 'which', 'who', 'when', 'where', 'why', 'how',
            'i', 'you', 'he', 'she', 'it', 'we', 'they', 'me', 'him', 'her',
            'us', 'them', 'my', 'your', 'his', 'her', 'its', 'our', 'their',
            'this', 'that', 'these', 'those', 'to', 'of', 'in', 'for', 'on',
            'with', 'at', 'by', 'from', 'as', 'if', 'not', 'no', 'yes'
        }
        tokens = [t for t in tokens if len(t) > 1 and t not in stopwords]
        return tokens
    
    def get_best_score(self, query: str, domain: Optional[str] = None) -> float:
        """Get the best BM25 score for a query."""
        results = self.retrieve(query, domain=domain, top_k=1)
        if results:
            return results[0][2]  # confidence
        return 0.0


def retrieve_relevant_chunks(
    query: str,
    chunks: List[Chunk],
    scorer: BM25Scorer,
    domain: Optional[str] = None,
    top_k: int = 5,
    confidence_threshold: float = 0.4
) -> Tuple[List[Tuple[Chunk, float]], bool, str]:
    """
    High-level retrieval function.
    
    Returns:
        (retrieved_chunks, should_escalate, reason)
        - retrieved_chunks: list of (chunk, confidence) tuples
        - should_escalate: True if confidence too low
        - reason: explanation if escalating
    """
    retriever = Retriever(chunks, scorer, confidence_threshold)
    results = retriever.retrieve(query, domain=domain, top_k=top_k)
    
    if not results:
        return [], True, "No relevant documentation found"
    
    best_confidence = results[0][2]
    
    if best_confidence < confidence_threshold:
        return results, True, f"Low retrieval confidence ({best_confidence:.2f})"
    
    # Return as (chunk, confidence) tuples
    clean_results = [(chunk, confidence) for chunk, score, confidence in results]
    return clean_results, False, ""


if __name__ == '__main__':
    from corpus import load_corpus
    
    # Test retrieval
    print("Loading corpus...")
    chunks, scorer = load_corpus()
    
    print("\nTesting retrieval:")
    
    test_queries = [
        ("How do I create a test?", "hackerrank"),
        ("API context window size", "claude"),
        ("Stolen card what to do", "visa"),
    ]
    
    for query, expected_domain in test_queries:
        print(f"\nQuery: {query}")
        print(f"Expected domain: {expected_domain}")
        
        results, should_escalate, reason = retrieve_relevant_chunks(
            query, chunks, scorer, domain=None, top_k=3
        )
        
        if should_escalate:
            print(f"  -> ESCALATE: {reason}")
        else:
            print(f"  -> Found {len(results)} results:")
            for chunk, confidence in results:
                print(f"     [{confidence:.2f}] {chunk.heading[:60]}")
